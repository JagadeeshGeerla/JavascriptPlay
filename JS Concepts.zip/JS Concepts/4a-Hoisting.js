// console.log(a);
// console.log(b);
// var a = b;
// var b = 'b';
// console.log(a);
// console.log(b);

/////////////////////////////

foo(); 
var foo = 2;
foo();
//bar()

function foo() {
    console.log("foo");
}
var bar = function baz() {
    console.log("bar");
}

//bar();

////////////////////////////


