


var foo = 'this is foo from file1';

