


(function () {
    var foo = 'Ha.. Access denied!';    
})();