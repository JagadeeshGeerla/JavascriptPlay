var a;
var b;
console.log(a);
console.log(b);
a = b;
b = 'b';
console.log(a);
console.log(b);