var foo = function bar() {
	var foo = "baz";
	console.log('Inside the func');

}();

foo();


