var obj = { foo: 'foo', baz: 99 }   
