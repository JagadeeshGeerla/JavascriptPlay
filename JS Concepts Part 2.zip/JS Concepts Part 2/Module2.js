const moduleApi = require('./Module1');

console.log(moduleApi);