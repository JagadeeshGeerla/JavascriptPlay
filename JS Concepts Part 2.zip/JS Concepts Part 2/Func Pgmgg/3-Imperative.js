var name = 'World';

console.log('Hello ' + name);

name = 'Universe';

console.log('Hello ' + name);