
function greet(name) {
    return('Hello ' + name);
}

console.log(greet('World'));

console.log(greet('Universe'));