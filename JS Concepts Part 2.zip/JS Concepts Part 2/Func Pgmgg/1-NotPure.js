var name = 'World';

function greet() {
    console.log('Hello ' + name);
}

greet();

name = 'Universe';

greet();