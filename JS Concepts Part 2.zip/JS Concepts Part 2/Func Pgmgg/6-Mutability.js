

var numSysts = ['Roman', 'Arabic', 'Chinese'];

numSysts[1] = 'Hindu-' + numSysts[1];

console.log(numSysts);